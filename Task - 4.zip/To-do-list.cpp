#include <iostream>
#include <vector>
#include <string>

struct Task {
    std::string description;
    bool completed;

    Task(const std::string &desc) : description(desc), completed(false) {}
};

class ToDoList {
private:
    std::vector<Task> tasks;

public:
    void addTask() {
        std::string taskDescription;
        std::cout << "Enter the task description: ";
        std::cin.ignore();
        std::getline(std::cin, taskDescription);
        tasks.emplace_back(taskDescription);
        std::cout << "Task added!\n";
    }

    void viewTasks() const {
        if (tasks.empty()) {
            std::cout << "No tasks available.\n";
            return;
        }

        std::cout << "To-Do List:\n";
        for (size_t i = 0; i < tasks.size(); ++i) {
            std::cout << i + 1 << ". [" << (tasks[i].completed ? "X" : " ") << "] "
                      << tasks[i].description << "\n";
        }
    }

    void markTaskCompleted() {
        if (tasks.empty()) {
            std::cout << "No tasks available to mark as completed.\n";
            return;
        }

        size_t taskNumber;
        std::cout << "Enter the task number to mark as completed: ";
        std::cin >> taskNumber;

        if (taskNumber > 0 && taskNumber <= tasks.size()) {
            tasks[taskNumber - 1].completed = true;
            std::cout << "Task marked as completed!\n";
        } else {
            std::cout << "Invalid task number.\n";
        }
    }

    void removeTask() {
        if (tasks.empty()) {
            std::cout << "No tasks available to remove.\n";
            return;
        }

        size_t taskNumber;
        std::cout << "Enter the task number to remove: ";
        std::cin >> taskNumber;

        if (taskNumber > 0 && taskNumber <= tasks.size()) {
            tasks.erase(tasks.begin() + taskNumber - 1);
            std::cout << "Task removed!\n";
        } else {
            std::cout << "Invalid task number.\n";
        }
    }
};

int main() {
    ToDoList toDoList;
    int choice;

    do {
        std::cout << "\nTo-Do List Manager\n";
        std::cout << "1. Add Task\n";
        std::cout << "2. View Tasks\n";
        std::cout << "3. Mark Task as Completed\n";
        std::cout << "4. Remove Task\n";
        std::cout << "5. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                toDoList.addTask();
                break;
            case 2:
                toDoList.viewTasks();
                break;
            case 3:
                toDoList.markTaskCompleted();
                break;
            case 4:
                toDoList.removeTask();
                break;
            case 5:
                std::cout << "Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
